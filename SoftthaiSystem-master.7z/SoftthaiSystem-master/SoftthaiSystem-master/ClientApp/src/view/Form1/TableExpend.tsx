import React from 'react';
import MUIDataTable from "mui-datatables";

export default function TableExpend() {
    return (
        <div>
            
        </div>
    )
}
